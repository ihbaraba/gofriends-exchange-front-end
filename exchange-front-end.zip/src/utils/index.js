export { default as getCoinsList } from './getCoinsList';
export { default as sendOrder } from './sendOrder';
export { default as getMarcketDpthData } from './getMarcketDpthData';
export { default as getUserInfo } from './getUserInfo';
export { default as getOrdersHistory } from './getOrdersHistory';
export { default as intervalInDays } from './intervalInDays';